<?xml version='1.0'?>
<!-- 	

	Filename:          NA_EAD_conv0.9.xsl
	Short description: XSLT conversiescript tbv DTNA productiestraat. 
	                   Dit document bevat een XSLT script waarmee een EAD 
	                   gestructureerd XML document kan worden omgezet in HTML
	                   bestanden. 
	Version:           0.9
	Last updated:      2003-01-03
	Status:            Chunking and testing to be finalized
	Owner:             Nationaal Archief
	Created by:	   HdH:   Hugo den Hollander (Daidalos BV)
			   JdH:   Jan den Hartog (Daidalos BV) 
	Copyright (c):     2003 Nationaal Archief, Den Haag, The Netherlands

-->
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
			      xmlns:msxsl="urn:schemas-microsoft-com:xslt"
			      xmlns:na="http://www.nationaalarchief.nl"
			      exclude-result-prefixes="xsl na msxsl">

<xsl:output method="xml"
            media-type="text/html"
            encoding="iso-8859-1"
            omit-xml-declaration="yes"/>

<msxsl:script language="JScript" implements-prefix="na">
 <![CDATA[

	var	outputFile = new Array();

	function OpenIfClosed( nFileNr )
	{
		var objFile = outputFile[ nFileNr ];
		if ( !objFile )
		{
			openDoc( nFileNr, "eadfout" + nFileNr.toString() + ".html" );
		}
	}

	
	function openDoc( nFileNr, strFileName )
	{
		var objFS;
		
		try
		{
			objFS = new ActiveXObject("Scripting.FileSystemObject");
		
			outputFile[nFileNr] = objFS.CreateTextFile( strFileName, true );

		}
		catch( e )
		{
			return e.toString();
		}

		return "";
	}
	
	function writeNodes( nFileNr, nodelistNodes )
	{
		try
		{
			var	nLength = nodelistNodes.length;

			OpenIfClosed( nFileNr );
			
			for (var i=0; i < nLength; i++ )
			{
				outputFile[nFileNr].WriteLine( nodelistNodes.item(i).xml );
			}
		}
		catch( e )
		{
			outputFile[nFileNr].Writeline( e.toString() );
		}
		finally
		{
			return "";
		}
	}

	function writeText( nFileNr, strText )
	{
		try
		{
			OpenIfClosed( nFileNr );
			outputFile[nFileNr].WriteLine( strText );
		}
		catch( e )
		{
			outputFile[nFileNr].Writeline( e.toString() );
		}
		finally
		{
			return "";
		}
	}


	function closeDoc( nFileNr )
	{
		var	objFile;
		
		objFile = outputFile[ nFileNr ]
		if ( objFile )
		{
			objFile.Close();
			outputFile[ nFileNr ] = null;
		}
		return "";
	}


	function closeAll()
	{
		for ( var i = 0; i != outputFile.length; i++ )
		{
			closeDoc( i );
		}
		return "";
	}

]]>	
</msxsl:script>

<xsl:variable name = "strPath" select = "'C:\NA\test\'" />
<xsl:variable name = "strTableWidth" select = "'600px'"/>
<xsl:variable name = "strCol1" select = "'40px'"/>
<xsl:variable name = "strCol2" select = "'40px'"/>
<xsl:variable name = "strCol3" select = "'40px'"/>
<xsl:variable name = "strCol4" select = "'340px'"/>
<xsl:variable name = "strCol5" select = "'140px'"/>
<xsl:variable name = "strTableborder" select = "'0'"/>

<xsl:template name="file.counter">
	<xsl:value-of select = "''"/>
</xsl:template>

<xsl:template name="filename.maker">
	<xsl:variable name = "intFilenumber">
		<xsl:call-template name = "file.counter"/>
	</xsl:variable>
	<xsl:choose>
		<xsl:when test = "/ead/eadheader/eadid">
			<xsl:value-of select = "concat(substring-before(string(/ead/eadheader/eadid), '.ead'), '.ead', $intFilenumber, '.html')"/>
		</xsl:when>
		<xsl:otherwise>
			<xsl:value-of select = "concat('ead-', generate-id(/ead), $intFilenumber, '.html')"/>
		</xsl:otherwise>
	</xsl:choose>
</xsl:template>

<xsl:template name="toc.maker">
		<html>
		<xsl:text>&#x0d;&#x0a;</xsl:text>
		<head>
		<xsl:text>&#x0d;&#x0a;</xsl:text>
		<meta http-equiv = "Content-Type" content ="text/html; charset=iso-8859-1" />
		<xsl:text>&#x0d;&#x0a;</xsl:text>
		<title>
			<xsl:value-of select = "//eadheader/eadid/filedesc/titlestmt/titleproper[1][normalize-space(string(.))]"/>
		</title>
		<xsl:text>&#x0d;&#x0a;</xsl:text>
		<script type = "text/javascript" language = "javascript1.2" src = "navigation.js">
		<xsl:text> </xsl:text>
		</script>
		<xsl:text>&#x0d;&#x0a;</xsl:text>
		<script type = "text/javascript" language = "javascript1.2">
	
		initNav();
		
		var showLevel = 0;
		
		<xsl:for-each select="/ead/archdesc/descgrp//head">
		tocItem(<xsl:value-of select="count(ancestor::*[head]) - 1"/>
			<xsl:text>, "</xsl:text>
			<xsl:value-of select="translate(string(.), '&#9;&#10;&#13;', '')"/>
			<xsl:text>", "</xsl:text>
			<xsl:call-template name="filename.maker"/>
			<xsl:text>#</xsl:text>
			<xsl:value-of select="generate-id(.)"/>
			<xsl:text>", </xsl:text>
			<xsl:choose>
				<xsl:when test = "count(parent::*//head) &gt; 1">
					<xsl:text>1</xsl:text>
				</xsl:when>
				<xsl:otherwise>
					<xsl:text>0</xsl:text>
				</xsl:otherwise>
			</xsl:choose>
			<xsl:text>);</xsl:text>
  		</xsl:for-each>
  		<xsl:for-each select="/ead/archdesc/dsc//unitid">
		tocItem(<xsl:value-of select="count(ancestor::*[starts-with(name(.), 'c0') or starts-with(name(.), 'c1')]/did/unitid) - 1"/>
			<xsl:text>, "</xsl:text>
			<xsl:value-of select="."/>
			<xsl:text>. </xsl:text>
			<xsl:value-of select="normalize-space(translate(following::unittitle[string(.)], '&#9;&#10;&#13;', ''))"/>
			<xsl:text>", "</xsl:text>
			<xsl:call-template name="filename.maker"/>
			<xsl:text>#</xsl:text>
			<xsl:value-of select="generate-id(.)"/>
			<xsl:text>", </xsl:text>
			<xsl:choose>
				<xsl:when test = "count(../..//unitid) &gt; 1">
					<xsl:text>1</xsl:text>
				</xsl:when>
				<xsl:otherwise>
					<xsl:text>0</xsl:text>
				</xsl:otherwise>
			</xsl:choose>
			<xsl:text>);</xsl:text>
  		</xsl:for-each>
  		<xsl:text>&#x0d;&#x0a;</xsl:text>
  		</script>
  		<xsl:text>&#x0d;&#x0a;</xsl:text>
  		<link rel = "stylesheet" type = "text/css" href = "stylesheet.css" />
  		<xsl:text>&#x0d;&#x0a;</xsl:text>
  		</head>
  		<xsl:text>&#x0d;&#x0a;</xsl:text>
  		<body bgcolor = "white" onLoad = "">
  		<xsl:text>&#x0d;&#x0a;</xsl:text>
  			<div id = "navigationDIV">
  			</div>
		<xsl:text>&#x0d;&#x0a;</xsl:text>
  		</body>
  		<xsl:text>&#x0d;&#x0a;</xsl:text>
  		</html>
</xsl:template>

<xsl:template name = "table.maker">
		<table>
			<xsl:attribute name="border">
				<xsl:value-of select = "$strTableborder" />
			</xsl:attribute>
			<xsl:attribute name="class">
				<xsl:value-of select="name(.)"/>
			</xsl:attribute>
			<xsl:attribute name="width">
				<xsl:value-of select="$strTableWidth"/>
			</xsl:attribute>		
			<tr>
				<td>
					<xsl:attribute name = "width">
						<xsl:value-of select = "$strCol1"/>
					</xsl:attribute>
				</td>
				<td>
					<xsl:attribute name = "width">
						<xsl:value-of select = "$strCol2"/>
					</xsl:attribute>
				</td>
				<td>
					<xsl:attribute name = "width">
						<xsl:value-of select = "$strCol3"/>
					</xsl:attribute>
				</td>
				<td>
					<xsl:attribute name = "width">
						<xsl:value-of select = "$strCol4"/>
					</xsl:attribute>
				</td>
				<td>
					<xsl:attribute name = "width">
						<xsl:value-of select = "$strCol5"/>
					</xsl:attribute>
				</td>
			</tr>
			<xsl:apply-templates/>
		</table>
</xsl:template>

<xsl:template name = "span.maker">
	<span>
		<xsl:attribute name="class">
			<xsl:value-of select="name(.)"/>
		</xsl:attribute>
		<xsl:apply-templates/>
	</span>
</xsl:template>

<xsl:template name = "div.maker">
	<div>
		<xsl:attribute name="class">
			<xsl:value-of select="name(.)"/>
		</xsl:attribute>
		<xsl:apply-templates/>
	</div>
</xsl:template>

<xsl:template name = "empty.td.maker">
	<td>
		<xsl:text disable-output-escaping="yes">&amp;nbsp;</xsl:text>
	</td>
</xsl:template>

<xsl:template name = "main.row.maker">
		<xsl:param name = "intUnitidtotal" select = "0"/>
		<xsl:param name = "intContext" select = "5"/>
		<xsl:param name = "intUnitidcounter" select = "1"/>
		<tr>
			<xsl:if test = "$intContext = 4">
				<xsl:call-template name = "empty.td.maker"/>
			</xsl:if>
			<xsl:if test = "$intContext = 3">
				<xsl:call-template name = "empty.td.maker"/>
				<xsl:call-template name = "empty.td.maker"/>
			</xsl:if>
			<td>
				<xsl:apply-templates select = "unitid[$intUnitidcounter]" mode = "withoutput"/>
			</td>
			<td>
				<xsl:attribute name="colspan">
					<xsl:value-of select = "$intContext - 1"/>
				</xsl:attribute>
				<xsl:choose>
					<xsl:when test = "unittitle[$intUnitidcounter]">
						<xsl:apply-templates select = "unittitle[$intUnitidcounter]" mode = "withoutput"/>
					</xsl:when>
					<xsl:otherwise>
						<xsl:text disable-output-escaping="yes">&amp;nbsp;</xsl:text>
					</xsl:otherwise>
				</xsl:choose>
			</td>
		</tr>
		<xsl:choose>
			<xsl:when test = "unitdate[$intUnitidcounter] or physdesc[$intUnitidcounter]">
				<tr>
				<xsl:call-template name = "empty.td.maker"/>					
				<xsl:if test = "$intContext = 4">
					<xsl:call-template name = "empty.td.maker"/>
				</xsl:if>
				<xsl:if test = "$intContext = 3">
					<xsl:call-template name = "empty.td.maker"/>
					<xsl:call-template name = "empty.td.maker"/>
				</xsl:if>
				<xsl:choose>
					<xsl:when test = "unitdate[$intUnitidcounter]">
						<td>
							<xsl:apply-templates select = "unitdate[$intUnitidcounter]" mode = "withoutput"/>
						</td>
					</xsl:when>
					<xsl:otherwise>
						<xsl:call-template name = "empty.td.maker"/>
					</xsl:otherwise>
				</xsl:choose>
				<xsl:choose>
					<xsl:when test="$intContext = 5">
						<xsl:call-template name = "empty.td.maker"/>
						<xsl:call-template name = "empty.td.maker"/>
					</xsl:when>
					<xsl:when test="$intContext = 4">
						<xsl:call-template name = "empty.td.maker"/>
					</xsl:when>
				</xsl:choose>
				<xsl:choose>
					<xsl:when test = "physdesc[$intUnitidcounter]">
						<td>
							<xsl:apply-templates select = "physdesc[$intUnitidcounter]" mode = "withoutput"/>
						</td>
					</xsl:when>
					<xsl:otherwise>
						<xsl:call-template name = "empty.td.maker"/>
					</xsl:otherwise>
				</xsl:choose>				
				</tr>	
			</xsl:when>
		</xsl:choose>
		<xsl:if test = "$intUnitidcounter &lt; $intUnitidtotal">
			<xsl:call-template name = "main.row.maker">
				<xsl:with-param name = "intUnitidtotal" select = "$intUnitidtotal"/>
				<xsl:with-param name = "intUnitidcounter" select = "$intUnitidcounter + 1"/>
				<xsl:with-param name = "intContext" select = "$intContext"/>
			</xsl:call-template>
		</xsl:if>
</xsl:template>

<xsl:template name="row.checker">
	<xsl:choose>
		<xsl:when test = "parent::*[starts-with(name(.), ('c0')) or starts-with(name(.), ('c1'))] |
   		      		  parent::did[parent::*[starts-with(name(.), ('c0')) or starts-with(name(.), ('c1'))]]">
		      	<xsl:variable name = "intContext">
		 		<xsl:call-template name="context.finder" />
		      	</xsl:variable>
			<xsl:call-template name="nb.table.row.maker">
				<xsl:with-param name = "intContext" select = "$intContext" />
			</xsl:call-template>
		</xsl:when>
		<xsl:otherwise>
			<div>
				<xsl:attribute name="class">
						<xsl:value-of select="name(.)"/>
				</xsl:attribute>
			<xsl:apply-templates/>
			</div>
		</xsl:otherwise>
	</xsl:choose>
</xsl:template>

<xsl:template name="nb.table.row.maker">
	<xsl:param name = "intContext" select = "''" />
	<tr>
		<xsl:attribute name="class">
			<xsl:call-template name="c.class.maker"/>
		</xsl:attribute>
		<xsl:call-template name = "empty.td.maker"/>
		<xsl:if test = "$intContext = 4">
				<xsl:call-template name = "empty.td.maker"/>
				<xsl:call-template name = "empty.td.maker"/>
		</xsl:if>
		<xsl:if test = "$intContext &lt; 3">
				<xsl:call-template name = "empty.td.maker"/>
				<xsl:call-template name = "empty.td.maker"/>
				<xsl:call-template name = "empty.td.maker"/>
		</xsl:if>
		<td>
			<xsl:attribute name="colspan">
					<xsl:value-of select="$intContext - 1"/>
			</xsl:attribute>
			<div>
				<xsl:attribute name="class">
					<xsl:call-template name="c.class.maker"/>
				</xsl:attribute>
				N.B. <xsl:apply-templates/>		
			</div>
		</td>
	</tr>
</xsl:template>

<xsl:template name="c.class.maker">
	<xsl:choose>
		<xsl:when test="ancestor::*[starts-with(name(.), ('c0')) or starts-with(name(.), ('c1'))][@level = 'file'] and ancestor::*[starts-with(name(.), ('c0')) or starts-with(name(.), ('c1'))][@level = 'otherlevel']">deel_<xsl:value-of select = "name(.)" />
		</xsl:when>
		<xsl:when test="ancestor::*[starts-with(name(.), ('c0')) or starts-with(name(.), ('c1'))][@level = 'file']">enkel_<xsl:value-of select = "name(.)" />
		</xsl:when>
		<xsl:when test="ancestor::*[starts-with(name(.), ('c0')) or starts-with(name(.), ('c1'))][@level = 'otherlevel']">verzamel_<xsl:value-of select = "count(ancestor::*[starts-with(name(.), 'c0')][@level = 'otherlevel'])"/>_<xsl:value-of select = "name(.)" />
		</xsl:when>
		<xsl:when test="ancestor::*[starts-with(name(.), ('c0')) or starts-with(name(.), ('c1'))][@level = 'series' or @level = 'subseries']">rubriek_<xsl:value-of select = "count(ancestor::*[starts-with(name(.), 'c0')][@level = 'series' or @level = 'subseries'])"/>_<xsl:value-of select = "name(.)" />
		</xsl:when>
	</xsl:choose>
</xsl:template>

<xsl:template match="/">
	<xsl:variable name = "strIndex">
		<xsl:call-template name = "toc.maker"/>	
	</xsl:variable>
	<xsl:variable name = "strIndexfile" select = "concat($strPath, 'index.js')"/>
	<xsl:value-of select="na:openDoc(0, $strIndexfile)" />
	<xsl:value-of select="na:writeNodes(0, $strIndex )" />
	<xsl:value-of select="na:closeDoc(0)" />
	<html>
		<head>
			<title>
				<xsl:value-of select="//titleproper[text()]"/>
			</title>
		</head>
		<body>	
			<xsl:apply-templates/>
		</body>
	</html>    		
	<xsl:value-of select="na:closeAll()" />
</xsl:template>

<xsl:template match="c01">
	<xsl:call-template name = "table.maker"/>
</xsl:template>

<xsl:template match="c02 | c03 | c04 | c05 | c06 | c07 | c08 | c09 | c10 | c11 | c12">
	<xsl:apply-templates/>
</xsl:template>

<xsl:template match="head">
	<a name="{generate-id(.)}"></a>
	<xsl:choose>
		<xsl:when test="ancestor::*[starts-with(name(.), 'c0') or starts-with(name(.), 'c1')]">
			<tr>
				<xsl:attribute name="class">
					<xsl:call-template name="c.class.maker"/>
				</xsl:attribute>
			<xsl:apply-templates/>
			</tr>
		</xsl:when>
		<xsl:otherwise>
			<xsl:call-template name="div.maker"/>
		</xsl:otherwise>
	</xsl:choose>
</xsl:template>

<xsl:template name = "context.finder">
	<xsl:choose>
		<xsl:when test = "count(ancestor::*[starts-with(name(.), 'c0') or starts-with(name(.), 'c1')][@level = 'file' or @level = 'otherlevel']) = 2">
			<xsl:value-of select = "4"/>
		</xsl:when>
		<xsl:when test = "count(ancestor::*[starts-with(name(.), 'c0') or starts-with(name(.), 'c1')][@level = 'file' or @level = 'otherlevel']) = 3">
			<xsl:value-of select = "3"/>
		</xsl:when>
		<xsl:when test = "count(ancestor::*[starts-with(name(.), 'c0') or starts-with(name(.), 'c1')][@level = 'file' or @level = 'otherlevel']) &gt; 3">
			<xsl:value-of select = "2"/>
		</xsl:when>
		<xsl:otherwise>
			<xsl:value-of select = "5"/>
		</xsl:otherwise>
	</xsl:choose>
</xsl:template>

<xsl:template match="did">
	<xsl:choose>
		<xsl:when test="parent::*[starts-with(name(.), ('c0')) or starts-with(name(.), ('c1'))]">
				<xsl:variable name = "intContext">
					<xsl:call-template name  = "context.finder" />
				</xsl:variable>
				<xsl:call-template name = "main.row.maker">
					<xsl:with-param name = "intContext" select = "$intContext"/>
					<xsl:with-param name = "intUnitidtotal" select = "count(unitid)"/>
				</xsl:call-template>
			<xsl:apply-templates/>
		</xsl:when>
		<xsl:otherwise>
			<xsl:call-template name = "div.maker" />
		</xsl:otherwise>
	</xsl:choose>
</xsl:template>

<xsl:template match="extent">
	<xsl:call-template name="span.maker"/>
</xsl:template>

<xsl:template match = "unitid | unittitle | unitdate | physdesc" mode = "withoutput">
	<xsl:choose>
		<xsl:when test = "name() = 'unitdate' and parent::unittitle">
			<xsl:call-template name = "span.maker" />
		</xsl:when>
		<xsl:otherwise>
			<div>
				<xsl:attribute name="class">
					<xsl:call-template name="c.class.maker"/>
				</xsl:attribute>
				<a name="{generate-id(.)}">
					<xsl:apply-templates/>
				</a>
			</div>
		</xsl:otherwise>
	</xsl:choose>
</xsl:template>

<xsl:template match = "unitid | unittitle | unitdate | physdesc">
	<xsl:choose>
		<xsl:when test = "name() = 'unitdate' and parent::unittitle">
			<xsl:call-template name = "span.maker" />
		</xsl:when>
		<xsl:otherwise>
			<xsl:if test = "not(ancestor::*[starts-with(name(.), 'c0') or starts-with(name(.), 'c1')])">
				<xsl:call-template name = "div.maker" />
			</xsl:if>
		</xsl:otherwise>
	</xsl:choose>
</xsl:template>

<xsl:template match="abstract | accessrestrict | accruals | acqinfo | address | addressline | altformavail | appraisal | arc | archdesc | arrangement | author | bibliography | bibseries | bioghist | blockquote | change | colspec | container | controlaccess | creation | custodhist | daodesc | daogrp | defitem | descgrp | descrules | dimensions | div | dsc | ead | eadheader | eadid | edition | editionstmt | event | eventgrp | extptr | filedesc | fileplan | frontmatter | head01 | head02 | imprint | label | langmaterial | language | langusage | lb | legalstatus | linkgrp | listhead | materialspec | namegrp |  note | notestmt | odd | originalsloc | origination | otherfindaid | p | physfacet | physloc | phystech | prefercite | processinfo | profiledesc | ptr | ptrgrp | publicationstmt | publisher | relatedmaterial | repository | resource | revisiondesc | runner | scopecontent | separatedmaterial | seriesstmt | sponsor | subtitle | titlepage | titleproper | titlestmt | userestrict">
	<xsl:call-template name = "row.checker"/>
</xsl:template>

<xsl:template match="emph | date | abbr | expan | num | title | corpname | famname | function | genreform | geogname | name | occupation | persname | subject | subarea | archref | bibref | dao | daoloc | extptrloc | extref | extrefloc | ptrloc | ref | refloc">
	<xsl:call-template name="span.maker"/>
</xsl:template>

<xsl:template match="table">
	<table>
		<xsl:attribute name="class">
			<xsl:value-of select="name(.)"/>
		</xsl:attribute>
		<xsl:apply-templates/>
	</table>
</xsl:template>

<xsl:template match="tgroup">
		<xsl:apply-templates/>
</xsl:template>

<xsl:template match="tbody">
	<tbody>
		<xsl:attribute name="class">
			<xsl:value-of select="name(.)"/>
		</xsl:attribute>
	</tbody>
</xsl:template>

<xsl:template match="thead">
	<th>
		<xsl:attribute name="class">
			<xsl:value-of select="name(.)"/>
		</xsl:attribute>
	</th>
</xsl:template>

<xsl:template match="row">
	<tr>
		<xsl:attribute name="class">
			<xsl:value-of select="name(.)"/>
		</xsl:attribute>
	</tr>
</xsl:template>

<xsl:template match="entry">
	<td>
		<xsl:attribute name="class">
			<xsl:value-of select="name(.)"/>
		</xsl:attribute>
	</td>
</xsl:template>

<xsl:template match="chronlist | list | index">
	<ul>
		<xsl:attribute name="class">
			<xsl:value-of select="name(.)"/>
		</xsl:attribute>
		<xsl:apply-templates/>
	</ul>
</xsl:template>

<xsl:template match="chronitem | item | indexentry">
	<li>
		<xsl:attribute name="class">
			<xsl:value-of select="name(.)"/>
		</xsl:attribute>
		<xsl:apply-templates/>
	</li>
</xsl:template>

</xsl:stylesheet>
