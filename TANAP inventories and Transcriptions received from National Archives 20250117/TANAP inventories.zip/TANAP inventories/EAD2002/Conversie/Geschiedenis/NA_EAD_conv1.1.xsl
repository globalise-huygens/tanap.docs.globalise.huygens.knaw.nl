<?xml version='1.0'?>
<!-- 	

	Filename:          NA_EAD_conv1.1.xsl
	Short description: XSLT conversiescript tbv DTNA productiestraat. 
	                   Dit document bevat een XSLT script waarmee een EAD 
	                   gestructureerd XML document kan worden omgezet in HTML
	                   bestanden. 
	Version:           1.1
	Last updated:      2003-02-13
	Status:            Reviewed, tested
	Owner:             Nationaal Archief
	Created by:	   HdH:   Hugo den Hollander (Daidalos BV)
			   JdH:   Jan den Hartog (Daidalos BV)
			   IZ:    Ivo Zandhuis
	History: 	   1.0.1  JdH:  Added chunking for c#[@level = 'subfonds' or @level = 'series' or @level = 'subseries'] elements
	 				Created file.maker named template to handle chunking
	 				Modified file.counter to handle c#[@level = 'subfonds' or @level = 'series' or @level = 'subseries'] elements
	 				Removed function writeText (not used)
	 		   1.0.2  JdH:  Aanmaken van <tr> bij C01 niet juist, aangepast
	 		   1.0.3  IZ:	<index> en <indexentry> worden <div>'s
	 		   		&amp;nbps; vervangen door spatie
	 		   1.0.9  JdH:  Added support for <note> elements as separate files
	 		   		Unittitles are no longer wrapped in <a name = "x"></a>
	 		   		References to subfiles now include unitid in hyperlink
	 		   		Label attribute of elemenst in high-level did are converted to <div class = "kop">
	 		   		Double quotes in javascript file are now single quotes
	 		   1.1	  JdH:	Added support for <c# level = "subfonds">
	 		   		Names of parent unittitles included in 'chopped' c# files
	 		   		Internal xrefs (to did[@id] elements only!) now working properly
	 		   		
	Copyright (c):     2003 Nationaal Archief, Den Haag, The Netherlands
-->

<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform"
			      xmlns:msxsl="urn:schemas-microsoft-com:xslt"
			      xmlns:na="http://www.nationaalarchief.nl"
			      exclude-result-prefixes="xsl na msxsl">

<xsl:output method = "html"
	    doctype-public = "-//W3C//DTD HTML 4.01 Transitional//EN"
            media-type = "text/html"
            encoding = "iso-8859-1"
            
/>


<msxsl:script language="JScript" implements-prefix="na">
 <![CDATA[

	var	outputFile = new Array();

	function OpenIfClosed( nFileNr )
	{
		var objFile = outputFile[ nFileNr ];
		if ( !objFile )
		{
			openDoc( nFileNr, "eadfout" + nFileNr.toString() + ".html" );
		}
	}

	
	function openDoc( nFileNr, strFileName )
	{
		var objFS;
		
		try
		{
			objFS = new ActiveXObject("Scripting.FileSystemObject");
		
			outputFile[nFileNr] = objFS.CreateTextFile( strFileName, true );

		}
		catch( e )
		{
			return e.toString();
		}

		return "";
	}
	
	function writeNodes( nFileNr, nodelistNodes )
	{
		try
		{
			var	nLength = nodelistNodes.length;

			OpenIfClosed( nFileNr );
			
			for (var i=0; i < nLength; i++ )
			{
				outputFile[nFileNr].WriteLine( nodelistNodes.item(i).xml );
			}
		}
		catch( e )
		{
			outputFile[nFileNr].Writeline( e.toString() );
		}
		finally
		{
			return "";
		}
	}

	function closeDoc( nFileNr )
	{
		var	objFile;
		
		objFile = outputFile[ nFileNr ]
		if ( objFile )
		{
			objFile.Close();
			outputFile[ nFileNr ] = null;
		}
		return "";
	}


	function closeAll()
	{
		for ( var i = 0; i != outputFile.length; i++ )
		{
			closeDoc( i );
		}
		return "";
	}

]]>	
</msxsl:script>

<!-- These parameters are set by the DTNA application -->
<xsl:param name = "strPath" select = "'C:\TEMP\'" />
<xsl:param name = "strXMLFilename" select = "'dummy.ead.xml'" />

<!-- General user-configurable variables -->
<xsl:variable name = "strStylesheet" select = "'../stylesheet.css'"/>
<xsl:variable name = "strIndexfilename" select = "'index.htm'"/>

<xsl:variable name = "strTableWidth" select = "'600px'"/>
<xsl:variable name = "strCol1" select = "'40px'"/>
<xsl:variable name = "strCol2" select = "'40px'"/>
<xsl:variable name = "strCol3" select = "'40px'"/>
<xsl:variable name = "strCol4" select = "'340px'"/>
<xsl:variable name = "strCol5" select = "'140px'"/>
<xsl:variable name = "strTableborder" select = "'0'"/>

<xsl:template name="file.counter">
	<xsl:variable name = "strPreceding" select = "count(preceding::*[starts-with(name(.), 'c0') or starts-with(name(.), 'c1')][@level = 'subfonds' or @level = 'series' or @level = 'subseries']) + count(ancestor::*[starts-with(name(.), 'c0') or starts-with(name(.), 'c1')][@level = 'subfonds' or @level = 'series' or @level = 'subseries'])"/>
	<xsl:variable name = "intPreceding">
		<xsl:choose>
			<xsl:when test = "self::*[starts-with(name(.), 'c0') or starts-with(name(.), 'c1')][@level = 'subfonds' or @level = 'series' or @level = 'subseries']">
				<xsl:value-of select = "$strPreceding + 1"/>
			</xsl:when>
			<xsl:otherwise>
				<xsl:value-of select = "$strPreceding"/>
			</xsl:otherwise>
		</xsl:choose>
	</xsl:variable>
	<xsl:variable name = "intFilenumber">
		<xsl:choose>
			<xsl:when test = "$intPreceding = 0">
				<xsl:value-of select = "''"/>
			</xsl:when>
			<xsl:otherwise>
				<xsl:value-of select = "$intPreceding"/>
			</xsl:otherwise>
		</xsl:choose>
	</xsl:variable>
	<xsl:value-of select = "$intFilenumber"/>
</xsl:template>

<xsl:template name="filename.maker">
	<xsl:variable name = "intFilenumber">
		<xsl:call-template name = "file.counter"/>
	</xsl:variable>
	<xsl:value-of select = "concat(substring-before($strXMLFilename, '.xml'), $intFilenumber, '.html')"/>
</xsl:template>

<xsl:template name="stylesheetlink.maker">
	<link>
		<xsl:attribute name = "rel">
			<xsl:value-of select = "'stylesheet'"/>
		</xsl:attribute>
		<xsl:attribute name = "type">
			<xsl:value-of select = "'text/css'"/>
		</xsl:attribute>
		<xsl:attribute name = "href">
			<xsl:value-of select = "$strStylesheet"/>
		</xsl:attribute>
	</link>
</xsl:template>

<xsl:template name="toc.maker">
		<html>
		<xsl:text>&#x0d;&#x0a;</xsl:text>
		<head>
		<xsl:text>&#x0d;&#x0a;</xsl:text>
		<meta http-equiv = "Content-Type" content ="text/html" />
		<xsl:text>&#x0d;&#x0a;</xsl:text>
		<title>
			<xsl:value-of select = "//eadheader/eadid/filedesc/titlestmt/titleproper[1][normalize-space(string(.))]"/>
		</title>
		<xsl:text>&#x0d;&#x0a;</xsl:text>
		<script type = "text/javascript" language = "javascript1.2" src = "navigation.js">
		<xsl:text> </xsl:text>
		</script>
		<xsl:text>&#x0d;&#x0a;</xsl:text>
		<script type = "text/javascript" language = "javascript1.2">
	
		initNav();
		
		var showLevel = 0;
		
		<xsl:for-each select="/ead/archdesc/descgrp//head">
		tocItem(<xsl:value-of select="count(ancestor::*[head]) - 1"/>
			<xsl:text>, '</xsl:text>
			<xsl:value-of select="translate(string(.), '&#9;&#10;&#13;', '')"/>
			<xsl:text>', '</xsl:text>
			<xsl:call-template name="filename.maker"/>
			<xsl:text>#</xsl:text>
			<xsl:value-of select="generate-id(.)"/>
			<xsl:text>', </xsl:text>
			<xsl:choose>
				<xsl:when test = "count(parent::*//head) &gt; 1">
					<xsl:text>1</xsl:text>
				</xsl:when>
				<xsl:otherwise>
					<xsl:text>0</xsl:text>
				</xsl:otherwise>
			</xsl:choose>
			<xsl:text>);</xsl:text>
  		</xsl:for-each>
  		<xsl:for-each select="/ead/archdesc/dsc//unitid">
		tocItem(<xsl:value-of select="count(ancestor::*[starts-with(name(.), 'c0') or starts-with(name(.), 'c1')]/did/unitid) - 1"/>
			<xsl:text>, '</xsl:text>
			<xsl:value-of select="."/>
			<xsl:text>. </xsl:text>
			<xsl:value-of select="normalize-space(translate(following::unittitle[string(.)], '&#9;&#10;&#13;', ''))"/>
			<xsl:text>', '</xsl:text>
			<xsl:call-template name="filename.maker"/>
			<xsl:text>#</xsl:text>
			<xsl:value-of select="generate-id(.)"/>
			<xsl:text>', </xsl:text>
			<xsl:choose>
				<xsl:when test = "count(../..//unitid) &gt; 1">
					<xsl:text>1</xsl:text>
				</xsl:when>
				<xsl:otherwise>
					<xsl:text>0</xsl:text>
				</xsl:otherwise>
			</xsl:choose>
			<xsl:text>);</xsl:text>
  		</xsl:for-each>
  		<xsl:text>&#x0d;&#x0a;</xsl:text>
  		</script>
  		<xsl:text>&#x0d;&#x0a;</xsl:text>
  		<xsl:call-template name = "stylesheetlink.maker" />
  		<xsl:text>&#x0d;&#x0a;</xsl:text>
  		</head>
  		<xsl:text>&#x0d;&#x0a;</xsl:text>
  		<body bgcolor = "white" onLoad = "">
  		<xsl:text>&#x0d;&#x0a;</xsl:text>
  			<div id = "navigationDIV">
  			<xsl:text>&#x0d;&#x0a;</xsl:text>
  			</div>
		<xsl:text>&#x0d;&#x0a;</xsl:text>
  		</body>
  		<xsl:text>&#x0d;&#x0a;</xsl:text>
  		</html>
</xsl:template>

<xsl:template name = "table.maker">
		<table>
			<xsl:attribute name="border">
				<xsl:value-of select = "$strTableborder" />
			</xsl:attribute>
			<xsl:attribute name="class">
				<xsl:value-of select="name(.)"/>
			</xsl:attribute>
			<xsl:attribute name="width">
				<xsl:value-of select="$strTableWidth"/>
			</xsl:attribute>
			<xsl:attribute name="summary">
				<xsl:value-of select = "'none'" />
			</xsl:attribute>
			<tr>
				<td>
					<xsl:attribute name = "width">
						<xsl:value-of select = "$strCol1"/>
					</xsl:attribute>
				</td>
				<td>
					<xsl:attribute name = "width">
						<xsl:value-of select = "$strCol2"/>
					</xsl:attribute>
				</td>
				<td>
					<xsl:attribute name = "width">
						<xsl:value-of select = "$strCol3"/>
					</xsl:attribute>
				</td>
				<td>
					<xsl:attribute name = "width">
						<xsl:value-of select = "$strCol4"/>
					</xsl:attribute>
				</td>
				<td>
					<xsl:attribute name = "width">
						<xsl:value-of select = "$strCol5"/>
					</xsl:attribute>
				</td>
			</tr>
			<xsl:for-each select="ancestor::*[starts-with(name(.), ('c0')) or starts-with(name(.), ('c1'))]">
				<tr>
					<td>
						<xsl:value-of select = "did/unitid"/>
					</td>
					<td  colspan = "4">
						<xsl:value-of select = "did/unittitle"/>
					</td>
				</tr>
			</xsl:for-each>	
			<xsl:apply-templates/>
		</table>
</xsl:template>

<xsl:template name = "span.maker">
	<span>
		<xsl:attribute name="class">
			<xsl:value-of select="name(.)"/>
		</xsl:attribute>
		<xsl:apply-templates/>
	</span>
</xsl:template>

<xsl:template name = "div.maker">
	<xsl:choose>
		<xsl:when test = "parent::did[parent::archdesc]">
			<xsl:if test = "@label">
				<div class = "kop">
					<xsl:value-of select = "@label"/>
				</div>
			</xsl:if>
			<div>
				<xsl:attribute name="class">
					<xsl:value-of select="name(.)"/>
				</xsl:attribute>
				<xsl:apply-templates/>
			</div>
		</xsl:when>
		<xsl:otherwise>
			<div>
				<xsl:attribute name="class">
					<xsl:value-of select="name(.)"/>
				</xsl:attribute>
				<xsl:apply-templates/>
			</div>
		</xsl:otherwise>
	</xsl:choose>
</xsl:template>

<xsl:template name = "empty.td.maker">
	<td>
<!--		<xsl:text disable-output-escaping="yes">&nbsp;</xsl:text>  -->
		<xsl:text> </xsl:text> 
	</td>
</xsl:template>

<xsl:template name = "main.row.maker">
		<xsl:param name = "intUnitidtotal" select = "0"/>
		<xsl:param name = "intContext" select = "5"/>
		<xsl:param name = "intUnitidcounter" select = "1"/>
		<tr>
			<xsl:if test = "$intContext = 4">
				<xsl:call-template name = "empty.td.maker"/>
			</xsl:if>
			<xsl:if test = "$intContext = 3">
				<xsl:call-template name = "empty.td.maker"/>
				<xsl:call-template name = "empty.td.maker"/>
			</xsl:if>
			<td>
				<xsl:apply-templates select = "unitid[$intUnitidcounter]" mode = "withoutput"/>
			</td>
			<td>
				<xsl:attribute name="colspan">
					<xsl:value-of select = "$intContext - 1"/>
				</xsl:attribute>
				<xsl:choose>
					<xsl:when test = "unittitle[$intUnitidcounter]">
						<xsl:apply-templates select = "unittitle[$intUnitidcounter]" mode = "withoutput"/>
					</xsl:when>
					<xsl:otherwise>
<!--						<xsl:text disable-output-escaping="yes">&amp;nbsp;</xsl:text> -->
						<xsl:text> </xsl:text>
					</xsl:otherwise>
				</xsl:choose>
			</td>
		</tr>
		<xsl:choose>
			<xsl:when test = "unitdate[$intUnitidcounter] or physdesc[$intUnitidcounter]">
				<tr>
				<xsl:call-template name = "empty.td.maker"/>					
				<xsl:if test = "$intContext = 4">
					<xsl:call-template name = "empty.td.maker"/>
				</xsl:if>
				<xsl:if test = "$intContext = 3">
					<xsl:call-template name = "empty.td.maker"/>
					<xsl:call-template name = "empty.td.maker"/>
				</xsl:if>
				<xsl:choose>
					<xsl:when test = "unitdate[$intUnitidcounter]">
						<td>
							<xsl:apply-templates select = "unitdate[$intUnitidcounter]" mode = "withoutput"/>
						</td>
					</xsl:when>
					<xsl:otherwise>
						<xsl:call-template name = "empty.td.maker"/>
					</xsl:otherwise>
				</xsl:choose>
				<xsl:choose>
					<xsl:when test="$intContext = 5">
						<xsl:call-template name = "empty.td.maker"/>
						<xsl:call-template name = "empty.td.maker"/>
					</xsl:when>
					<xsl:when test="$intContext = 4">
						<xsl:call-template name = "empty.td.maker"/>
					</xsl:when>
				</xsl:choose>
				<xsl:choose>
					<xsl:when test = "physdesc[$intUnitidcounter]">
						<td>
							<xsl:apply-templates select = "physdesc[$intUnitidcounter]" mode = "withoutput"/>
						</td>
					</xsl:when>
					<xsl:otherwise>
						<xsl:call-template name = "empty.td.maker"/>
					</xsl:otherwise>
				</xsl:choose>				
				</tr>	
			</xsl:when>
		</xsl:choose>
		<xsl:if test = "$intUnitidcounter &lt; $intUnitidtotal">
			<xsl:call-template name = "main.row.maker">
				<xsl:with-param name = "intUnitidtotal" select = "$intUnitidtotal"/>
				<xsl:with-param name = "intUnitidcounter" select = "$intUnitidcounter + 1"/>
				<xsl:with-param name = "intContext" select = "$intContext"/>
			</xsl:call-template>
		</xsl:if>
</xsl:template>

<xsl:template name="row.checker">
	<xsl:choose>
		<xsl:when test = "parent::*[starts-with(name(.), ('c0')) or starts-with(name(.), ('c1'))] |
   		      		  parent::did[parent::*[starts-with(name(.), ('c0')) or starts-with(name(.), ('c1'))]]">
		      	<xsl:variable name = "intContext">
		 		<xsl:call-template name="context.finder" />
		      	</xsl:variable>
			<xsl:call-template name="nb.table.row.maker">
				<xsl:with-param name = "intContext" select = "$intContext" />
			</xsl:call-template>
		</xsl:when>
		<xsl:otherwise>
			<xsl:call-template name = "div.maker"/>
		</xsl:otherwise>
	</xsl:choose>
</xsl:template>

<xsl:template name="nb.table.row.maker">
	<xsl:param name = "intContext" select = "''" />
	<tr>
		<xsl:attribute name="class">
			<xsl:call-template name="c.class.maker"/>
		</xsl:attribute>
		<xsl:call-template name = "empty.td.maker"/>
		<xsl:if test = "$intContext = 4">
				<xsl:call-template name = "empty.td.maker"/>
				<xsl:call-template name = "empty.td.maker"/>
		</xsl:if>
		<xsl:if test = "$intContext &lt; 3">
				<xsl:call-template name = "empty.td.maker"/>
				<xsl:call-template name = "empty.td.maker"/>
				<xsl:call-template name = "empty.td.maker"/>
		</xsl:if>
		<td>
			<xsl:attribute name="colspan">
					<xsl:value-of select="$intContext - 1"/>
			</xsl:attribute>
			<div>
				<xsl:attribute name="class">
					<xsl:call-template name="c.class.maker"/>
				</xsl:attribute>
				<xsl:apply-templates/>
			</div>
		</td>
	</tr>
</xsl:template>

<xsl:template name="c.class.maker">
	<xsl:choose>
		<xsl:when test="ancestor::*[starts-with(name(.), ('c0')) or starts-with(name(.), ('c1'))][@level = 'file'] and ancestor::*[starts-with(name(.), ('c0')) or starts-with(name(.), ('c1'))][@level = 'otherlevel']">deel_<xsl:value-of select = "name(.)" />
		</xsl:when>
		<xsl:when test="ancestor::*[starts-with(name(.), ('c0')) or starts-with(name(.), ('c1'))][@level = 'file']">enkel_<xsl:value-of select = "name(.)" />
		</xsl:when>
		<xsl:when test="ancestor::*[starts-with(name(.), ('c0')) or starts-with(name(.), ('c1'))][@level = 'otherlevel']">verzamel_<xsl:value-of select = "count(ancestor::*[starts-with(name(.), 'c0')][@level = 'otherlevel'])"/>_<xsl:value-of select = "name(.)" />
		</xsl:when>
		<xsl:when test="ancestor::*[starts-with(name(.), ('c0')) or starts-with(name(.), ('c1'))][@level = 'series' or @level = 'subseries']">rubriek_<xsl:value-of select = "count(ancestor::*[starts-with(name(.), 'c0')][@level = 'series' or @level = 'subseries'])"/>_<xsl:value-of select = "name(.)" />
		</xsl:when>
		<xsl:when test="ancestor::*[starts-with(name(.), ('c0')) or starts-with(name(.), ('c1'))][@level = 'subfonds']">subfonds_<xsl:value-of select = "count(ancestor::*[starts-with(name(.), 'c0')][@level = 'subfonds'])"/>_<xsl:value-of select = "name(.)" />
		</xsl:when>
	</xsl:choose>
</xsl:template>

<xsl:template name = "file.maker">
	<xsl:variable name = "strFilename">
		<xsl:call-template name="filename.maker"/>
	</xsl:variable>
	<xsl:variable name="strFilenumber">
		<xsl:call-template name="file.counter"/>
	</xsl:variable>
	<xsl:variable name = "strFullFilename" select = "concat($strPath, $strFilename)"/>
	<xsl:variable name = "strFilecont">
		<html>
			<head>
				<title>
					<xsl:value-of select="//titleproper[text()]"/>
					<xsl:text> </xsl:text>
					<xsl:value-of select="did/unittitle"/>
				</title>
				<xsl:call-template name = "stylesheetlink.maker" />
			</head>
			<body>
				<xsl:call-template name = "table.maker"/>
			</body>
		</html>
	</xsl:variable>
	<xsl:value-of select="na:openDoc(string($strFilenumber), string($strFullFilename))" />
	<xsl:value-of select="na:writeNodes(string($strFilenumber), $strFilecont )" />
	<xsl:value-of select="na:closeDoc(string($strFilenumber))" />
	<xsl:choose>
		<xsl:when test = "self::c01">
			<p>
				<a>
					<xsl:attribute name = "href">
						<xsl:call-template name="filename.maker"/>
					</xsl:attribute>
					<xsl:value-of select="did/unitid"/>
					<xsl:text> </xsl:text>
					<xsl:value-of select="did/unittitle"/>
				</a>
			</p>
		</xsl:when>
		<xsl:otherwise>
			<tr>
				<td>
					<a>
						<xsl:attribute name = "href">
							<xsl:call-template name="filename.maker"/>
						</xsl:attribute>
						<xsl:value-of select="did/unitid"/>
					</a>
				</td>
				<td colspan = "4">
					<a>
						<xsl:attribute name = "href">
							<xsl:call-template name="filename.maker"/>
						</xsl:attribute>
						<xsl:value-of select="did/unittitle"/>
					</a>				
				</td>
			</tr>
		</xsl:otherwise>
	</xsl:choose>
</xsl:template>

<xsl:template name = "link.target.maker">
	<xsl:if test = "@id">
		<a>
			<xsl:attribute name = "name">
				<xsl:value-of select = "@id"/>
			</xsl:attribute>
		</a>
	</xsl:if>
</xsl:template>

<xsl:template match="/">
	<xsl:variable name = "strIndex">
		<xsl:call-template name = "toc.maker"/>	
	</xsl:variable>
	<xsl:variable name = "strIndexfile" select = "concat($strPath, $strIndexfilename)"/>
	<xsl:value-of select="na:openDoc(0, $strIndexfile)" />
	<xsl:value-of select="na:writeNodes(0, $strIndex )" />
	<xsl:value-of select="na:closeDoc(0)" />
	<html>
		<head>
			<title>
				<xsl:value-of select="//titleproper[text()]"/>
			</title>
			<xsl:call-template name = "stylesheetlink.maker" />
		</head>
		<body>	
			<xsl:apply-templates/>
		</body>
	</html>    		
	<xsl:value-of select="na:closeAll()" />
</xsl:template>

<xsl:template match = "*[starts-with(name(.), 'c0') or starts-with(name(.), 'c1')][@level = 'subfonds' or @level = 'series' or @level = 'subseries']">
	<xsl:call-template name = "file.maker"/>
</xsl:template>

<xsl:template match = "c01">
	<xsl:call-template name = "table.maker"/>
</xsl:template>

<xsl:template match="c02 | c03 | c04 | c05 | c06 | c07 | c08 | c09 | c10 | c11 | c12">
	<xsl:apply-templates/>
</xsl:template>

<xsl:template match="head">
	<a name="{generate-id(.)}"></a>
	<xsl:choose>
		<xsl:when test="ancestor::*[starts-with(name(.), 'c0') or starts-with(name(.), 'c1')]">
			<tr>
				<xsl:attribute name="class">
					<xsl:call-template name="c.class.maker"/>
				</xsl:attribute>
			<xsl:apply-templates/>
			</tr>
		</xsl:when>
		<xsl:otherwise>
			<xsl:call-template name="div.maker"/>
		</xsl:otherwise>
	</xsl:choose>
</xsl:template>

<xsl:template name = "context.finder">
	<xsl:choose>
		<xsl:when test = "count(ancestor::*[starts-with(name(.), 'c0') or starts-with(name(.), 'c1')][@level = 'file' or @level = 'otherlevel']) = 2">
			<xsl:value-of select = "4"/>
		</xsl:when>
		<xsl:when test = "count(ancestor::*[starts-with(name(.), 'c0') or starts-with(name(.), 'c1')][@level = 'file' or @level = 'otherlevel']) = 3">
			<xsl:value-of select = "3"/>
		</xsl:when>
		<xsl:when test = "count(ancestor::*[starts-with(name(.), 'c0') or starts-with(name(.), 'c1')][@level = 'file' or @level = 'otherlevel']) &gt; 3">
			<xsl:value-of select = "2"/>
		</xsl:when>
		<xsl:otherwise>
			<xsl:value-of select = "5"/>
		</xsl:otherwise>
	</xsl:choose>
</xsl:template>

<xsl:template match="did">
	<xsl:call-template name = "link.target.maker"/>
	<xsl:choose>
		<xsl:when test="parent::*[starts-with(name(.), ('c0')) or starts-with(name(.), ('c1'))]">
				<xsl:variable name = "intContext">
					<xsl:call-template name  = "context.finder" />
				</xsl:variable>
				<xsl:call-template name = "main.row.maker">
					<xsl:with-param name = "intContext" select = "$intContext"/>
					<xsl:with-param name = "intUnitidtotal" select = "count(unitid)"/>
				</xsl:call-template>
			<xsl:apply-templates/>
		</xsl:when>
		<xsl:otherwise>
			<xsl:call-template name = "div.maker" />
		</xsl:otherwise>
	</xsl:choose>
</xsl:template>

<xsl:template match="extent">
	<xsl:call-template name="span.maker"/>
</xsl:template>

<xsl:template match = "unitid | unittitle | unitdate | physdesc" mode = "withoutput">
	<xsl:choose>
		<xsl:when test = "name() = 'unitdate' and parent::unittitle">
			<xsl:call-template name = "span.maker" />
		</xsl:when>
		<xsl:otherwise>
			<div>
				<xsl:attribute name="class">
					<xsl:call-template name="c.class.maker"/>
				</xsl:attribute>
				<a name="{generate-id(.)}"></a>
				<xsl:apply-templates/>
			</div>
		</xsl:otherwise>
	</xsl:choose>
</xsl:template>

<xsl:template match = "unitid | unittitle | unitdate | physdesc">
	<xsl:choose>
		<xsl:when test = "name() = 'unitdate' and parent::unittitle">
			<xsl:call-template name = "span.maker" />
		</xsl:when>
		<xsl:otherwise>
			<xsl:if test = "not(ancestor::*[starts-with(name(.), 'c0') or starts-with(name(.), 'c1')])">
				<xsl:call-template name = "div.maker" />
			</xsl:if>
		</xsl:otherwise>
	</xsl:choose>
</xsl:template>

<xsl:template match="abstract | accessrestrict | accruals | acqinfo | address | addressline | altformavail | appraisal | arc | archdesc | arrangement | author | bibliography | bibseries | bioghist | blockquote | change | colspec | container | controlaccess | creation | custodhist | daodesc | daogrp | defitem | descgrp | descrules | dimensions | div | dsc | ead | eadheader | eadid | edition | editionstmt | event | eventgrp | extptr | filedesc | fileplan | frontmatter | head01 | head02 | imprint | index | indexentry | label | langmaterial  | langusage | lb | legalstatus | linkgrp | listhead | materialspec | namegrp | notestmt | odd | originalsloc | origination | otherfindaid | p | physfacet | physloc | phystech | prefercite | processinfo | profiledesc | ptr | ptrgrp | publicationstmt | publisher | relatedmaterial | repository | resource | revisiondesc | runner | scopecontent | separatedmaterial | seriesstmt | sponsor | subtitle | titlepage | titleproper | titlestmt | userestrict">
	<xsl:call-template name = "row.checker"/>
</xsl:template>

<xsl:template match="emph | date | abbr | expan | num | title | corpname | famname | function | genreform | geogname | name | occupation | persname | subject | subarea | archref | bibref | dao | daoloc | extptrloc | extref | extrefloc | ptrloc | refloc | language">
	<xsl:call-template name="span.maker"/>
</xsl:template>

<xsl:template match="note">
	<xsl:variable name = "intNotenumber">
		<xsl:number level="any" count="note" format="1" />
	</xsl:variable>
	<xsl:variable name = "strNotefilename">
		<xsl:value-of select="concat(substring-before($strXMLFilename, '.xml'), '-n' , $intNotenumber, '.html')"/>
	</xsl:variable>
	<xsl:variable name = "strFullFilename" select = "concat($strPath, $strNotefilename)"/>
	<xsl:variable name = "strNotecont">
		<html>
			<head>
				<title>
					<xsl:value-of select="//titleproper[text()]"/>
					<xsl:text> - noot </xsl:text>
					<xsl:value-of select = "$intNotenumber"/>
				</title>
				<xsl:call-template name = "stylesheetlink.maker" />
			</head>
			<body>
				<xsl:apply-templates/>
			</body>
		</html>
	</xsl:variable>
	<sup class="note">
		<a>
            		<xsl:attribute name="href">
            			<xsl:value-of select = "$strNotefilename"/>
            		</xsl:attribute>
            		<xsl:number level="any" count="note" format="1" />
		</a>
	</sup>
	<xsl:value-of select="na:openDoc(100, string($strFullFilename))" />
	<xsl:value-of select="na:writeNodes(100, $strNotecont )" />
	<xsl:value-of select="na:closeDoc(100)" />
</xsl:template>

<xsl:template match="table">
	<table>
		<xsl:attribute name="class">
			<xsl:value-of select="name(.)"/>
		</xsl:attribute>
		<xsl:apply-templates/>
	</table>
</xsl:template>

<xsl:template match="tgroup">
		<xsl:apply-templates/>
</xsl:template>

<xsl:template match="tbody">
	<tbody>
		<xsl:attribute name="class">
			<xsl:value-of select="name(.)"/>
		</xsl:attribute>
	</tbody>
</xsl:template>

<xsl:template match="thead">
	<th>
		<xsl:attribute name="class">
			<xsl:value-of select="name(.)"/>
		</xsl:attribute>
	</th>
</xsl:template>

<xsl:template match="row">
	<tr>
		<xsl:attribute name="class">
			<xsl:value-of select="name(.)"/>
		</xsl:attribute>
	</tr>
</xsl:template>

<xsl:template match="entry">
	<td>
		<xsl:attribute name="class">
			<xsl:value-of select="name(.)"/>
		</xsl:attribute>
	</td>
</xsl:template>

<xsl:template match="chronlist | list">
	<ul>
		<xsl:attribute name="class">
			<xsl:value-of select="name(.)"/>
		</xsl:attribute>
		<xsl:apply-templates/>
	</ul>
</xsl:template>

<xsl:template match = "change/item | defitem/item">
	<xsl:call-template name = "div.maker" />
</xsl:template>

<xsl:template match="chronitem | item  | defitem">
	<li>
		<xsl:attribute name="class">
			<xsl:value-of select="name(.)"/>
		</xsl:attribute>
		<xsl:apply-templates/>
	</li>
</xsl:template>

<xsl:template match = "did" mode = "linktarget">
	<xsl:call-template name = "filename.maker"/>
</xsl:template>

<xsl:template match = "ref">
	<xsl:variable name = "strTargetid">
		<xsl:value-of select = "@target"/>
	</xsl:variable>
	<a>
		<xsl:attribute name = "href">
			<xsl:apply-templates select = "//did[@id = $strTargetid]" mode = "linktarget"/>
			<xsl:text>#</xsl:text>
			<xsl:value-of select = "@target"/>
		</xsl:attribute>
		<xsl:apply-templates/>
	</a>
</xsl:template>

</xsl:stylesheet>
