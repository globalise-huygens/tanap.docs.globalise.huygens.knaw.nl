<?xml version="1.0"?>
<!DOCTYPE MACROS SYSTEM "macros.dtd">
<MACROS>
<MACRO name="Preview or Print PDF" key="" lang="JScript" id="1162"><![CDATA[
//Call the function to view the PDF file
previewPDF();
]]></MACRO>
<MACRO name="XML To PDF Setup" key="" lang="JScript"><![CDATA[
XMLToPDFSetup();
]]></MACRO>
</MACROS>