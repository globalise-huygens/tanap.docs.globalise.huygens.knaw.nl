<?xml version="1.0" encoding="UTF-8"?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
	<xsl:output method="html" version="1.0" encoding="iso-8859-1" indent="yes"/>
	
	<xsl:template match="/">
		<html>
			<head>
				<title>
					<xsl:value-of select="//header/shorttitle"></xsl:value-of>
					<xsl:text> </xsl:text>
					<xsl:value-of select="//header/version"></xsl:value-of>
					</title>
					
				<style type="text/css">
<xsl:comment><xsl:text>P, OL, LI, I, U	{
			margin-left: 80px;
			margin-right: 80px;
			}

BODY			{
			font-family: Verdana;
			font-size: 10pt;
			}
			
PRE			{
			margin-left: 80px;
			}					
			
EMPH.attribute {
			font-variant: small-caps;}
			
A.elm {
			color: black;
			text-decoration: none; }


</xsl:text>	</xsl:comment>			
				</style>
			</head>
			<body>
				<xsl:apply-templates></xsl:apply-templates>
			</body>
		</html>
	</xsl:template>
	
	<xsl:template match="attributename">
		<emph>
			<xsl:attribute name="class">attribute</xsl:attribute>
			<xsl:apply-templates></xsl:apply-templates>
		</emph>
	</xsl:template>
	
	<xsl:template match="ref">
		<a>
			<xsl:attribute name="href"><xsl:value-of select="@url"></xsl:value-of></xsl:attribute>
			<xsl:apply-templates></xsl:apply-templates>
		</a>
	</xsl:template>
	
	<xsl:template match="code">
		<pre>
			<xsl:apply-templates></xsl:apply-templates>
		</pre>
	</xsl:template>
	
	<xsl:template match="header">
		<center>
			<xsl:apply-templates></xsl:apply-templates>
		</center>
	</xsl:template>
	
	<xsl:template match="list">
		
		<ol>
			<xsl:apply-templates></xsl:apply-templates>
		</ol>
	</xsl:template>
	
	<xsl:template match="item">
		<li>
			<xsl:apply-templates></xsl:apply-templates>
		</li>
	</xsl:template>
	
	<xsl:template match="p | author | titleproper | shorttitle | publisher">
		<p>
			<xsl:apply-templates></xsl:apply-templates>
		</p>
	</xsl:template>
	
	<xsl:template match="/guidelines/div/head">
		<h2>
			<xsl:number format="1.1.1. " level="multiple" count="div"></xsl:number>
			<xsl:apply-templates></xsl:apply-templates>
		</h2>
	</xsl:template>
	
	<xsl:template match="/guidelines/div/div/head">
		<h3>
			<xsl:number format="1.1.1. " level="multiple" count="div"></xsl:number>
			<xsl:apply-templates></xsl:apply-templates>
		</h3>
	</xsl:template>
	
	<xsl:template match="afspraak/head">
		<u>
			<xsl:apply-templates></xsl:apply-templates>
		</u>		
	</xsl:template>
	
	<xsl:template match="/guidelines/div/div/div/head">
		<h4>
			<xsl:number format="1.1.1. " level="multiple" count="div"></xsl:number>
			<xsl:apply-templates></xsl:apply-templates>
		</h4>
	</xsl:template>
	
	<xsl:template match="elementname">
		<xsl:element name="a">
		<xsl:attribute name="href">
			<xsl:text>http://www.loc.gov/ead/tglib/elements/</xsl:text>
			<xsl:value-of select="."></xsl:value-of>
			<xsl:text>.html</xsl:text>
		</xsl:attribute>
		<xsl:attribute name="class">elm</xsl:attribute> 
			<xsl:text>&lt;</xsl:text>
			<xsl:apply-templates></xsl:apply-templates>
			<xsl:text>&gt;</xsl:text>
		</xsl:element> 
	</xsl:template>
		
	<xsl:template match="check | check_not"></xsl:template>	
		
</xsl:stylesheet>
